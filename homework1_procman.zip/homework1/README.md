# procman - Process Manager

**Author:** Joksan Haziel Pelayo Oliva  
**Student ID:** 5107960  
**Email:** joksan@example.com  

## Overview

`procman` es un administrador de procesos simple escrito en C que permite:

- Crear procesos hijo que ejecutan comandos externos.
- Monitorear el estado de los procesos.
- Terminar procesos de forma controlada o forzada.
- Manejar señales (`SIGINT`, `SIGCHLD`) para apagado limpio y prevención de zombis.
- Visualizar un árbol de procesos a partir del PID de `procman`.
- Ofrecer una interfaz interactiva estilo shell.

## Compilation Instructions

Requisitos:

- Compilador C (gcc).
- Sistema tipo Linux con `/proc` disponible.

Para compilar:

```bash
make
```

Para limpiar binarios:

```bash
make clean
```

## Usage Instructions

Ejecutar el programa:

```bash
./procman
```

Comandos disponibles en la shell interactiva:

```text
help                          - Muestra ayuda
create <command> [args...]    - Crea un nuevo proceso hijo
list                          - Lista procesos administrados
kill <pid> [force]            - Termina proceso (force=1 usa SIGKILL)
tree                          - Muestra árbol de procesos desde procman
wait                          - Espera a que terminen todos los procesos
quit                          - Sale del programa
```

Ejemplos:

```bash
ProcMan> create sleep 5
ProcMan> list
ProcMan> wait
ProcMan> quit
```

## Design Decisions

- **Tabla de procesos estática:** Se utiliza un arreglo estático de tamaño `MAX_PROCESSES` para simplificar el manejo (no se usa memoria dinámica compleja).
- **Sincronización con señales:**  
  - Se bloquea `SIGCHLD` cuando se modifica la tabla de procesos para evitar condiciones de carrera.
  - El manejador de `SIGCHLD` se encarga de llamar a `waitpid(..., WNOHANG)` y actualizar el estado de los procesos, evitando zombis.
- **Shell interactiva simple:**  
  - Se usa `strtok_r` para dividir la línea en tokens por espacios.
  - No se implementa un parser completo de comillas o caracteres especiales (ver "Known Limitations").
- **Árbol de procesos:**  
  - Se lee información desde `/proc/[pid]/stat` para construir la relación padre-hijo.
  - Se usa una función recursiva para imprimir el árbol con caracteres `├─` y `└─`.

## Challenges

- Manejar correctamente `SIGCHLD` y `waitpid` para prevenir procesos zombi sin interferir con otras llamadas a `wait` en el programa.
- Diseñar una representación simple, pero legible, del árbol de procesos usando el sistema de archivos `/proc`.
- Evitar condiciones de carrera al actualizar la tabla de procesos tanto desde el hilo principal como desde el manejador de señales.

## Testing

Hay tres scripts de prueba en `test_scripts/`:

- `test1.sh`: comprobación básica de creación y terminación de procesos.
- `test2.sh`: prueba del manejo de señales (`SIGINT`, `SIGCHLD`).
- `test3.sh`: prueba del árbol de procesos con múltiples niveles.

Para ejecutar todas las pruebas:

```bash
make test
```

## Known Limitations

- El parsing de la línea de comandos en la shell es básico:
  - No soporta comillas ni escapes avanzados.
  - Comandos como `bash -c "sleep 30 & sleep 60 & wait"` pueden no interpretarse exactamente como en un shell real.
- La visualización del árbol de procesos depende del contenido de `/proc` y puede variar según el sistema.
- El programa asume un máximo de `MAX_PROCESSES` procesos administrados simultáneamente.
- No se almacena la línea de comando completa con todos los argumentos, solo el comando principal en la tabla de procesos (para simplificar).

## Memory Checking

Para correr `valgrind`:

```bash
make valgrind
```

## System Call Tracing

Para trazar llamadas al sistema relacionadas con procesos:

```bash
make strace
```
