# Lab 1.4: GRUB Configuration and Boot Process Analysis

**Student:** Joksan Haziel Pelayo Oliva  
**Date:** 2025-11-30  
**Course:** Operating Systems  

## Executive Summary
Este laboratorio tuvo como objetivo analizar, modificar y validar la configuración del gestor de arranque GRUB en un sistema Linux.  
Se revisó el archivo principal `/etc/default/grub`, se identificaron los parámetros más importantes, se modificó el tiempo de espera del menú (timeout) a 30 segundos, se forzó la visualización del menú de arranque y se regeneró el archivo `grub.cfg` utilizando `update-grub`.  
Posteriormente se verificó que el sistema siguiera iniciando correctamente y se investigaron distintos métodos de recuperación en caso de que GRUB falle o quede corrupto.

## Objectives Completed
- Analizar la configuración actual de GRUB.
- Documentar valores de `GRUB_TIMEOUT`, `GRUB_DEFAULT` y `GRUB_CMDLINE_LINUX_DEFAULT`.
- Contar el número de entradas en el menú de arranque.
- Modificar el archivo `/etc/default/grub` con nuevos parámetros.
- Generar un nuevo archivo de configuración con `sudo update-grub`.
- Verificar que el sistema arranca correctamente con los cambios.
- Investigar al menos tres métodos de recuperación de GRUB.
- Crear scripts de respaldo y restauración con manejo básico de errores.
- Organizar el repositorio con la estructura solicitada.

## Main Changes Implemented
- `GRUB_TIMEOUT` cambiado de `5` a `30` para dar más tiempo de interacción al usuario.
- Añadido `GRUB_TIMEOUT_STYLE=menu` para que el menú se muestre de forma consistente.
- Confirmado `GRUB_DEFAULT=0` para que la primera entrada del menú sea la predeterminada.
- Mantenido `GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"` para conservar la experiencia de arranque gráfica.
- Asegurado `GRUB_CMDLINE_LINUX=""` sin parámetros extra no necesarios.
- Generado un nuevo archivo `grub.cfg` mediante `sudo update-grub`.

## Key Learnings
- El archivo `/etc/default/grub` define parámetros de alto nivel, pero no es el archivo que GRUB lee directamente al arrancar.
- Es obligatorio ejecutar `sudo update-grub` (o `grub-mkconfig`) después de realizar cambios para que se apliquen.
- Un error de sintaxis en la configuración de GRUB puede dejar el sistema sin poder arrancar.
- GRUB cuenta con modos de rescate (`grub rescue>` y `grub>`) que permiten arrancar el sistema de forma manual.
- El uso de un Live USB combinado con `chroot` es una estrategia muy potente para reparar o reinstalar GRUB.
- Mantener respaldos del archivo `/etc/default/grub` es una buena práctica para recuperar la configuración rápidamente.

## Evidence Files
- `docs/pre-lab-analysis.md`: análisis del estado inicial y valores encontrados.
- `docs/configuration-changes.md`: descripción detallada de los cambios realizados.
- `docs/grub-recovery-guide.md`: guía de recuperación con varios métodos.
- `docs/lessons-learned.md`: resumen de aprendizajes y reflexiones finales.
- `configs/grub-default-original.txt`: copia de la configuración original.
- `configs/grub-default-modified.txt`: configuración después de las modificaciones.
- `configs/grub-cfg-analysis.txt`: análisis del archivo `grub.cfg`.
- `scripts/grub-backup.sh`: script para crear respaldo del archivo de configuración.
- `scripts/grub-restore.sh`: script para restaurar desde un respaldo.
- `scripts/system-info.sh`: script para recolectar información del sistema.
- Archivos de la carpeta `screenshots/`: nombres reservados para las capturas de pantalla solicitadas en el laboratorio (deben ser reemplazadas por capturas reales desde la VM).
